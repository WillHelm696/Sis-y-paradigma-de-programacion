primero = int(input("INGRESE EL PRIMER VALOR:"))
segundo = int(input("INGRESE EL SEGUNDO VALOR:"))
tercero = int(input("INGRESE EL TERCERO VALOR:"))

if primero<0:
    multiplicacion = primero*segundo*tercero
    print ("La multiplicacion de los 3 es:", multiplicacion)
else:
    suma = primero+segundo+tercero
    print ("La suma de los 3 es:", suma)